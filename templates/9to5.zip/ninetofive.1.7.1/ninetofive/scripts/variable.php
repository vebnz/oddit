<?php session_start();
$_SESSION[$_POST['cat']] = $_POST['val']; ?>